package Model;

import java.util.List;

public class Estudiante {
    private Long id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private String preferencias;
    private List<Long> cursosInscritos; 
    private Double progresoTotal; 
    private List<String> cuponesDescuento; 

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getPreferencias() {
        return preferencias;
    }
    public void setPreferencias(String preferencias) {
        this.preferencias = preferencias;
    }
    public List<Long> getCursosInscritos() {
        return cursosInscritos;
    }
    public void setCursosInscritos(List<Long> cursosInscritos) {
        this.cursosInscritos = cursosInscritos;
    }
    public Double getProgresoTotal() {
        return progresoTotal;
    }
    public void setProgresoTotal(Double progresoTotal) {
        this.progresoTotal = progresoTotal;
    }
    public List<String> getCuponesDescuento() {
        return cuponesDescuento;
    }
    public void setCuponesDescuento(List<String> cuponesDescuento) {
        this.cuponesDescuento = cuponesDescuento;
    }
}
