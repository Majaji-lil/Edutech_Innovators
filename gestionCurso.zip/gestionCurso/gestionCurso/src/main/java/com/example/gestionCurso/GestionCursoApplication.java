package com.example.gestionCurso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionCursoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionCursoApplication.class, args);
	}

}
