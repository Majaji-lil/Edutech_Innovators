package com.example.gestionCurso.repository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.gestionCurso.model.Curso;

@Repository
public class CursoRepository {
    
    private List <Curso> listaCursos = new ArrayList <>();
    
    public List <Curso> obtenerCursos() {
    return listaCursos;

    }

public Curso buscarPorId(int id){
    for (Curso curso : listaCursos) {
        if(curso.getId()==id ){
            return curso;
        }
    }
    return null;
}


public Curso guardar (Curso cur ){
    listaCursos.add(cur);
    return cur;
}




public Curso actualizar(Curso cur){
    int id = 0;
    int idPosicion = 0;
    for (int i = 0; i <listaCursos.size(); i++){
        if (listaCursos.get(i).getId() == cur.getId()){
            id = cur.getId();
            idPosicion = i;

        }
        
    }
    Curso curso1 = new Curso();
    curso1.setId(id);
    curso1.setTitulo(cur.getTitulo());
    curso1.setDescripcion(cur.getDescripcion());
    curso1.setFechaInicio(cur.getFechaInicio());
    curso1.setFechaFin(cur.getFechaFin());
    curso1.setCupoMaximo(cur.getCupoMaximo());
    curso1.setInstructor(cur.getInstructor());
    curso1.setEstudiantesInscritos(cur.getEstudiantesInscritos());

    listaCursos.set(idPosicion, curso1);
    return curso1;

}

public void eliminar (int id) {
    Curso curso = buscarPorId(id);
    if (curso != null){
        listaCursos.remove(curso);

    }

 int idPosicion = 0; 
 for (int i = 0; i<listaCursos.size(); i++){
    if(listaCursos.get(i).getId()== id){
        idPosicion = i;
        break;

    }
    if (idPosicion > 0){
        listaCursos.remove(idPosicion);
    }
    listaCursos.removeIf (x -> x.getId()== id);
 }   
}





}
