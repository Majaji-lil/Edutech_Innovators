package com.example.gestionCurso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionCursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
