package com.evaparcial.n2.eva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
